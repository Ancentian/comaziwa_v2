<?php

return [
    'leave_days' => 21,
];
