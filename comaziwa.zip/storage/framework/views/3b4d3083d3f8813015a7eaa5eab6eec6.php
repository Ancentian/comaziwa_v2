<?php
    $is_admin_configured = optional(auth()->guard('employee')->user())->is_admin_configured;
    $tenant_id = null;
    if ($is_admin_configured == 1 ) {
        $employee_id = optional(auth()->guard('employee')->user())->id;
        $tenant_id = optional(auth()->guard('employee')->user())->tenant_id;
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <meta name="description" content="">
		<meta name="keywords" content="">
        <meta name="author" content="">
        <meta name="robots" content="noindex, nofollow">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name')); ?></title>	
        <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <style>
            .table{
                width: 100% !important;
            }
            .select{
                width: 100% !important;
            }
            .dt-buttons{
                margin-left: 25% !important;
            }
            .btn-sm {
              background-color: #8F3A84 !important;
                color: #fff !important;
                height: 30px !important;
                padding-top: 2px !important;
                padding-bottom: 2px !important;
            }
        </style>
    </head>

	
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">

        <?php if(session('is_admin') == 1): ?>
            <?php echo $__env->make('companies.staff.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('companies.staff.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
            
								
			<!-- Page Wrapper -->
            <div class="page-wrapper">

                <?php
                    $package = \App\Models\Package::find(auth()->user()->package_id);
                    $pp = !empty($package) ?  $package->price : 0;        
                ?>
			
				<!-- Page Content -->
                <div class="content container-fluid">
                    <?php if(((strtotime(auth()->user()->expiry_date) - time()) <= (env('ALERT_DAYS')*86400) && (strtotime(auth()->user()->expiry_date) - time()) > 0) && auth()->user()->type == 'client' && $pp > 0): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            Your subscription ends on <?php echo e(date('d/m/Y H:i',strtotime(auth()->user()->expiry_date))); ?> ! <a href="#" class="renew_subscription">Click here to renew</a>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                    <?php endif; ?>
					<?php echo $__env->yieldContent('content'); ?>
				
				</div>
				<!-- /Page Content -->

            </div>
			<!-- /Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->

        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.components', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        <?php echo $__env->make('layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <?php if(!auth()->user()->package_id && auth()->user()->type == 'client' && empty($tenant_id)): ?>
            <?php if($pp > 0 && empty($is_sub)): ?>
                <script>
                    $(document).ready(function() {
                        window.location.href = "<?php echo e(url('dashboard/subscriptions')); ?>";
                    });
                </script>
            <?php endif; ?>       
        <?php endif; ?>

        <?php if((strtotime(auth()->user()->expiry_date) - time()) <= 0 && auth()->user()->type == 'client'  && empty($tenant_id)): ?>
            <?php if($pp > 0 && empty($is_sub)): ?>
            <script>
                $(document).ready(function() {
                    $(document).ready(function() {
                        window.location.href = "<?php echo e(url('dashboard/subscriptions')); ?>";
                    });
                });
            </script>
            <?php endif; ?>
        <?php endif; ?>
        
        <script>
            $('.renew_subscription').on('click', function () {
                $("#renew_modal").modal('show');
            });
        </script>
        <?php echo $__env->yieldContent('javascript'); ?>
				
    </body>
</html><?php /**PATH C:\laragon\www\comaziwa\resources\views/layout/app.blade.php ENDPATH**/ ?>