<?php

namespace App\Http\Controllers;

use App\Models\CollectionCenter;
use App\Models\Employee;
use App\Models\Bank;
use App\Models\Farmer;
use App\Models\MilkCollection;
use App\Models\Deduction;
use App\Models\Expense;
use App\Models\Inventory;
use App\Models\ProductUnit;
use App\Models\StoreSale;
use App\Models\ShareContribution;
use App\Models\ShareSetting;
use App\Models\Payment;

use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Excel;

class PaymentsController extends Controller
{
    public function index()
    {
        return view('companies.payments.index');
    }

    public function generate(Request $request)
    {
        $tenant_id = auth()->user()->id;
        $centers = CollectionCenter::where('tenant_id', $tenant_id)->get();
        if (request()->ajax()) {
            $start_date = request()->start_date;
            $end_date = request()->end_date;

            $tenant_id = auth()->user()->id;

            $farmers = Farmer::join('collection_centers', 'collection_centers.id', '=', 'farmers.center_id')
                    ->join('banks', 'banks.id', '=', 'farmers.bank_id')
                    ->where('farmers.tenant_id', $tenant_id)
                    ->select([
                        'collection_centers.center_name',
                        'banks.bank_name',
                        'farmers.id as farmer_id',
                        'farmers.fname',
                        'farmers.lname',
                        'farmers.farmerID',
                        'farmers.center_id',
                    ])->get();
            return DataTables::of($farmers)
                ->addColumn('action', function ($row) {
                    $html = '<div class="btn-group">
                        <button type="button" class="badge btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
                        <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item edit-button" data-action="'.url('milkCollection/edit-milk-collection',[$row['farmer_id']]).'" href="#" ><i class="fa fa-pencil m-r-5"></i> Edit</a>
                        <a class="dropdown-item delete-button" data-action="'.url('milkCollection/delete-milk-collection',[$row['farmer_id']]).'" href="#" ><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                        </div>
                    </div>';
                    return $html;
                })

                ->addColumn('fullname', function ($row) {
                    return $row->fname.' '.$row->lname.' - '.$row->farmerID;
                })

                ->addColumn('farmer_id', function ($row) {
                    $farmer_id = $row->farmer_id;
                    return  $farmer_id;
                })

                ->addColumn('center_id', function ($row) {
                    $center_id = $row->center_id;
                    return  $center_id;
                })
                
                ->addColumn('total_milk', function ($row) {
                    $tenant_id = auth()->user()->id;
                    $farmer_id = $row->farmer_id;
                    $total_milk = DB::table('milk_collections')
                                ->where([
                                    ['farmer_id', '=', $farmer_id],
                                    ['tenant_id', '=', $tenant_id],
                                ])
                                ->sum('total') ?? 0;
                    return $total_milk;
                })

                ->editColumn('total_store_deductions', function ($row) {
                    $tenant_id = auth()->user()->id;
                    $farmer_id = $row->farmer_id;
                    $total_sales = DB::table('store_sales')
                                ->where([
                                    ['tenant_id', '=', $tenant_id],
                                    ['farmer_id', '=', $farmer_id],
                                ])
                                ->sum('total_cost') ?? 0;
                    return $total_sales;
    
                })
                ->editColumn('total_individual_deductions', function ($row) {
                    $tenant_id = auth()->user()->id;
                    $farmer_id = $row->farmer_id;
                
                    $individualDeductions = DB::table('deductions')
                        ->where([
                            ['tenant_id', '=', $tenant_id],
                            ['farmer_id', '=', $farmer_id],
                            ['deduction_type', '=', 'individual']
                        ])
                        ->sum('amount') ?? 0;
                    return $individualDeductions;
                })                
                ->editColumn('total_general_deductions', function ($row) {
                    $tenant_id = auth()->user()->id;
                
                    $generalDeductions = DB::table('deductions')
                        ->where([
                            ['tenant_id', '=', $tenant_id],
                            ['deduction_type', '=', 'general']
                        ])
                        ->sum('amount') ?? 0;
                    return $generalDeductions;
                })
                ->editColumn('total_shares', function ($row) {
                    $tenant_id = auth()->user()->id;
                    $farmer_id = $row->farmer_id;
                
                    // Retrieve the accumulative_amount from share_settings
                    $shareSettings = DB::table('share_settings')
                        ->where([
                            ['tenant_id', '=', $tenant_id],
                            ['is_active', '=', 1],
                        ])
                        ->select('accumulative_amount')
                        ->first();
                
                    // Ensure shareSettings is not null and get the accumulative_amount
                    $accumulativeAmount = $shareSettings ? $shareSettings->accumulative_amount : 0;

                    $totalShares = DB::table('share_contributions')
                        ->where([
                            ['tenant_id', '=', $tenant_id],
                            ['farmer_id', '=', $farmer_id],
                        ])
                        ->sum('share_value') ?? 0;

                    return $totalShares;
                })
                ->editColumn('previous_dues', function ($row) {
                    $tenant_id = auth()->user()->id;
                    $farmer_id = $row->farmer_id;
                
                    $total_dues = "0.00";
                    return $total_dues;
                })
                
                         
                ->rawColumns(['action', 'fullname','farmer_id', 'total_milk', 'total_store_deductions', 'total_individual_deductions', 'total_general_deductions', 'total_shares', 'previous_dues'])
                ->make(true);
        }
        return view('companies.payments.generate-payments', compact('centers'));
    }

    public function generate_payments()
    {
        if (request()->ajax()) {
            $start_date = request()->start_date;
            $end_date = request()->end_date;

            $tenant_id = auth()->user()->id;

            // Fetch milk collections
            $milk = MilkCollection::join('farmers', 'farmers.id', '=', 'milk_collections.farmer_id')
                ->where('milk_collections.tenant_id', $tenant_id)
                ->select([
                    'farmers.id as farmer_id',
                    'farmers.fname',
                    'farmers.lname',
                    'farmers.farmerID',
                    DB::raw('SUM(milk_collections.total) as total_milk')
                ]);

            if (!empty($start_date) && !empty($end_date)) {
                $milk->whereDate('milk_collections.collection_date', '>=', $start_date)
                    ->whereDate('milk_collections.collection_date', '<=', $end_date);
            }

            $milk = $milk->groupBy('farmers.id')->get();

            // Fetch store deductions
            $storeDeductions = StoreSale::join('farmers', 'farmers.id', '=', 'store_sales.farmer_id')
                ->where('store_sales.tenant_id', $tenant_id)
                ->select([
                    'farmers.id as farmer_id',
                    DB::raw('SUM(store_sales.total_cost) as total_store_deductions')
                ]);

            if (!empty($start_date) && !empty($end_date)) {
                $storeDeductions->whereDate('store_sales.order_date', '>=', $start_date)
                                ->whereDate('store_sales.order_date', '<=', $end_date);
            }

            $storeDeductions = $storeDeductions->groupBy('farmers.id')->get();

            // Fetch individual deductions
            $individualDeductions = Deduction::join('farmers', 'farmers.id', '=', 'deductions.farmer_id')
                ->where('deductions.tenant_id', $tenant_id)
                ->where('deductions.deduction_type', 'individual')
                ->select([
                    'farmers.id as farmer_id',
                    DB::raw('SUM(deductions.amount) as total_individual_deductions')
                ]);

            if (!empty($start_date) && !empty($end_date)) {
                $individualDeductions->whereDate('deductions.date', '>=', $start_date)
                                    ->whereDate('deductions.date', '<=', $end_date);
            }

            $individualDeductions = $individualDeductions->groupBy('farmers.id')->get();

            // Fetch general deductions
            $generalDeductions = Deduction::where('deductions.tenant_id', $tenant_id)
                ->where('deductions.deduction_type', 'general')
                ->select([
                    DB::raw('SUM(deductions.amount) as total_general_deductions')
                ]);

            if (!empty($start_date) && !empty($end_date)) {
                $generalDeductions->whereDate('deductions.date', '>=', $start_date)
                                ->whereDate('deductions.date', '<=', $end_date);
            }

            $generalDeductions = $generalDeductions->get();
            logger($generalDeductions);
            // Fetch shares
            $shares = ShareContribution::join('farmers', 'farmers.id', '=', 'share_contributions.farmer_id')
                ->where('share_contributions.tenant_id', $tenant_id)
                ->select([
                    'farmers.id as farmer_id',
                    DB::raw('SUM(share_contributions.share_value) as total_shares')
                ]);

            if (!empty($start_date) && !empty($end_date)) {
                $shares->whereDate('share_contributions.issue_date', '>=', $start_date)
                    ->whereDate('share_contributions.issue_date', '<=', $end_date);
            }

            $shares = $shares->groupBy('farmers.id')->get();
        

            //shares Settings
            $share_settings = ShareSetting::where('share_settings.tenant_id', $tenant_id)
                ->where('is_active', 1)
                    ->select([
                        'accumulative_amount'
                    ]);
            $share_settings = $share_settings->get();

            // Fetch previous dues
            // $previousDues = PreviousDue::join('farmers', 'farmers.id', '=', 'previous_dues.farmer_id')
            //     ->where('previous_dues.tenant_id', $tenant_id)
            //     ->select([
            //         'farmers.id as farmer_id',
            //         DB::raw('SUM(previous_dues.amount) as total_previous_dues')
            //     ]);

            // if (!empty($start_date) && !empty($end_date)) {
            //     $previousDues->whereDate('previous_dues.due_date', '>=', $start_date)
            //                  ->whereDate('previous_dues.due_date', '<=', $end_date);
            // }

            // $previousDues = $previousDues->groupBy('farmers.id')->get();

            // Combine results
            $results = $milk->map(function ($milk) use ($storeDeductions, $individualDeductions, $generalDeductions, $shares, $share_settings) {
                $farmer_id = $milk->farmer_id;
                $store_deduction = $storeDeductions->firstWhere('farmer_id', $farmer_id);
                $individual_deduction = $individualDeductions->firstWhere('farmer_id', $farmer_id);
                $general_deduction = $generalDeductions->first();
                $share = $shares->firstWhere('farmer_id', $farmer_id);
                $share_settings = $share_settings->first();
                //$previous_due = $previousDues->firstWhere('farmer_id', $farmer_id);

                return [
                    'farmer_id' => $farmer_id,
                    'fullname' => $milk->farmerID . ' - ' . $milk->fname . ' ' . $milk->lname,
                    'total_milk' => $milk->total_milk,
                    'total_store_deductions' => $store_deduction->total_store_deductions ?? 0,
                    'total_individual_deductions' => $individual_deduction->total_individual_deductions ?? 0,
                    'total_general_deductions' => $general_deduction->total_general_deductions ?? 0,
                    'total_shares' => $share->total_shares ?? 0,
                    'total_deductions' => $store_deduction->total_store_deductions ?? 0 + $individual_deduction->total_individual_deductions ?? 0 + $general_deduction->total_general_deductions ?? 0,
                    'share_settings' => $share_settings->accumulative_amount ?? 0,
                    //'total_previous_dues' => $previous_due->total_previous_dues ?? 0,
                ];
            });
            logger($results);
            return DataTables::of($results)
                ->addColumn('action', function ($row) {
                    $html = '<div class="btn-group">
                        <button type="button" class="badge btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
                        <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item edit-button" data-action="'.url('milkCollection/edit-milk-collection',[$row['farmer_id']]).'" href="#" ><i class="fa fa-pencil m-r-5"></i> Edit</a>
                        <a class="dropdown-item delete-button" data-action="'.url('milkCollection/delete-milk-collection',[$row['farmer_id']]).'" href="#" ><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                        </div>
                    </div>';
                    return $html;
                })
                ->editColumn('total_milk', function ($row) {
                    $html = '<input type="text" class="form-control" readonly value="'.$row['total_milk'].'">';
                    return $html;
                })
                ->editColumn('total_store_deductions', function ($row) {
                    $html = '<input type="text" class="form-control" readonly value="'.$row['total_store_deductions'].'">';
                    return $html;
                })
                ->editColumn('total_individual_deductions', function ($row) {
                    $html = '<input type="text" class="form-control" readonly value="'.$row['total_individual_deductions'].'">';
                    return $html;
                })
                ->editColumn('total_general_deductions', function ($row) {
                    $html = '<input type="text" class="form-control" readonly value="'.$row['total_general_deductions'].'">';
                    return $html;
                })
                ->editColumn('total_shares', function ($row) {
                    $html = '<input type="text" class="form-control" readonly value="'.$row['total_shares'].' of '.$row['share_settings'].'">';
                    return $html;
                })
                
                // ->editColumn('total_previous_dues', function ($row) {
                //     $html = '<input type="text" class="form-control" readonly value="'.$row['total_previous_dues'].'">';
                //     return $html;
                // })
                
                // ->editColumn('total_store_deductions', function ($row) {
                //     $html = num_format($row['total_store_deductions']);
                //     return $html;
                // })
                // ->editColumn('total_individual_deductions', function ($row) {
                //     $html = num_format($row['total_individual_deductions']);
                //     return $html;
                // })
                // ->editColumn('total_general_deductions', function ($row) {
                //     $html = num_format($row['total_general_deductions']);
                //     return $html;
                // })
                // ->editColumn('total_shares', function ($row) {
                //     $html = num_format($row['total_shares']);
                //     return $html;
                // })            
                ->rawColumns(['action', 'total_milk', 'total_store_deductions', 'total_individual_deductions', 'total_general_deductions', 'total_shares'])
                ->make(true);
        }

        return view('companies.payments.generate-payments');
    }

    // public function store_payments(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'farmer_id'  => 'required',
    //         'center_id'  => 'required',
    //         'total_milk' => 'required',
    //         'milk_rate' => '',
    //         'store_deductions' => 'required',
    //         'individual_deductions' => 'required',
    //         'general_deductions' => 'required',
    //         'shares_contribution' => 'required',
    //         'previous_dues' => 'required',
    //         'pay_period' => 'required',
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json(['errors' => $validator->errors()], 422);
    //     }

    //     logger($request->all());
    //     DB::beginTransaction();
    //     try {
    //         $tenant_id = auth()->user()->id;
    //         $user_id = auth()->user()->id;

    //         foreach ($request->farmer_id as $key => $ded) {
    //             $payment = [
    //                 'tenant_id' => $tenant_id,
    //                 'farmer_id' => $key,
    //                 'center_id' => $request->center_id,
    //                 'total_milk' => $request->total_milk[$key],
    //                 'milk_rate' => $request->milk_rate[$key],
    //                 'store_deductions' => $request->store_deductions[$key],
    //                 'individual_deductions' => $request->individual_deductions[$key],
    //                 'general_deductions' => $request->general_deductions[$key],
    //                 'shares_contribution' => $request->shares_contribution[$key],
    //                 'previous_dues' => $request->previous_dues[$key],
    //                 'generated_by' => $user_id,
    //                 'pay_period' => $request->pay_period,
    //                 'pay_date' => $request->pay_date,

    //             ];
    //             Payment::create($payment);
    //         }

    //         DB::commit();
    //         return response()->json(['message' => 'Payment Generated Added Successfully']);
    //     } catch (\Exception $e) {
    //         logger($e);
    //         DB::rollback();
    //         return response()->json(['message' => 'Data saving failed. Please try again.'], 500);
    //     }
    // }
}
